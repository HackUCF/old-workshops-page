<?php
	$password = str_split("AT2B1HDI");

	if (isset($_GET["passwd"])) {	
		$input = str_split($_GET["passwd"]);

		// this is really bad code im so sorry	
		$index = 0;
		$start_time = microtime(true);
		foreach ($password as $letter) {
			if ($input[$index] === $password[$index]) {
				usleep(20000);
			} else {
				usleep(20000/2);
				$difference = (microtime(true) - $start_time);
				die("WRONG.<br/><br/><br/><small><div class=\"footer\">Response generated in: <time>$difference</time></div><small>");
			}
			$index++;
		}

		if (sizeof($password) !== sizeof($input)) {
			$difference = (microtime(true) - $start_time);
			die("WRONG.<br/><br/><small><div class=\"footer\">this response generated in <time>$difference</time></div></small>");
		} else {
			die("key -> i_stole_this_challenge_idea_from_someone_else");
		}
	}
?>

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

<div class="container">
  <form action="medium2.php">
   <br/> password:
    <input type="text" name="passwd" class="input"/><br/>
  </form>
  </br>
</div>
