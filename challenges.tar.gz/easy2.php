<?php
session_start();

if (isset($_POST["answer"])) {
	echo("the answer: " . $_SESSION['answer'] . "<br/>");
	echo("your answer: " . htmlentities($_POST["answer"]) . "<br/>");

	if (time() - $_SESSION["time"] > 2) { // we tell them 1s but give 2s just because i'm nice
		die("too slow");
	}
	if (intval($_POST["answer"]) === intval($_SESSION["answer"])) {
		die("key is -> you_should_have_solved_this_in_ruby<br/><br/>");
	} else {
		die("wrong answer<br/><br/>");
	}	
}
?>



<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

<div class="container">
<?php
$numbers = array(rand(1000,10000), rand(1000,10000), rand(1000,10000), rand(1000,10000), rand(1000,10000));
$operators = array("*", "+", "-", "/");

shuffle($operators);

$string = "";

for ($i = 0; $i < 5; $i++) {
	$string .= $numbers[$i];
		if ($i < 4) { // add an operator 
			$string .= " ".$operators[$i]. " ";
		}
}

echo("you have 1 second to type the answer to the following problem, good luck! if only there was a better way...<br/></br>");
echo("<expression>".str_replace(" ", "<br/>", $string)."</expression>");

eval('$answer = floor(' . $string . ');'); 

$_SESSION["answer"] = $answer;
$_SESSION["time"] = time();
?>

  <form action="easy2.php" method="POST">
   <br/> answer (hint, the solution is floor()'d:
	 <input type="text" name="answer" class="input" value=""/><br/>
  </form>
	</br>
</div>
