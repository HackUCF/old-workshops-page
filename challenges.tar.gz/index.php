<a href="easy.php">easy 1</a><br/>
<a href="easy2.php">easy 2</a><br/>
<a href="/medium">medium</a><br/>
<a href="/medium2.php">medium2</a><br/

<br/><br/>
<h3>practice index</h3>

<a href="/practice/meet1.html">Meeting 1 (September 6)</a></br>
<a href="/practice/meet2">Meeting 2 (September 13)</a>
