<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

<?php
  $input = $_GET["passwd"];

  $password = "php_is_really_really_well_designed";

  if (strcmp($input, $password) == 0) {
    echo("The key is -> $password");
	} else {
		if (isset($_GET["passwd"])) {
			echo("wrong password");
		}
	}
?>

<div class="container">
  <form action="easy.php">
   <br/> password:
    <input type="text" name="passwd" class="input"/><br/>
  </form>
  </br>

  code:</br></br>
  <pre>
    $input = $_GET["passwd"];

    $password = "CENSORED";

    if (strcmp($input, $password) == 0) {
      echo("The key is -> $password");
    }
    </pre>
</div>
