

<?php
	# key is -> please_dont_hack_my_server
	# please make sure allow_url_fopen is enabled to retrieve URL links
?>

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<div class="container">

<?php
	session_start();
	// do a login
	if (isset($_POST["account"]) && !isset($_SESSION["account"])) {
		if (ctype_alnum($_POST["account"]) && strlen($_POST["account"]) >= 5 && strlen($_POST["account"]) <= 20) { 
			$_SESSION["account"] = $_POST["account"];
			# dear god make sure medium/ has an index.html or turn off directory listings
			mkdir("/var/www/medium/acc/".$_SESSION["account"], 0777, true);
		} else {
			die("5-20 chars length alphanumeric accounts only please");
		}
	}
?>

<?php
  // login block
  if(!isset($_SESSION["account"])) {
?>

  <form action="index.php" method="POST">
  	Please enter an alphanumeric passphrase to identify your unique account - you don't want others' guessing this.
		<input type="text" name="account" class="input" maxlength="20">
    <input type="submit"/>
  </form>

<?php
	// end login block
	} else {
	// begin challenge block	
		if (isset($_POST["url"])) {
			$url = $_POST["url"];
			if (stristr($url, "http://") == false ) {
				die("invalid file protocol/URL! it did not contain 'http://'");
			}

			//according to the Uniform Resource Locator specification, anything after # should not be parsed as a url, but php tries to parse it! remove everything after # for the sake of the challenge
			$url = explode("#", $url)[0];

			ini_set('open_basedir', '/var/www/medium') or die("error setting basedir");
			$file = fopen($url, 'r');
			if (!$file) {
				die("geeksquad&trade; secure_webserver&copy; exception caught in ".$_SERVER['SCRIPT_FILENAME'].": </br> error retrieving file! are you sure it exists? <br/><br/>hint/note: open_basedir is on!");
			}
			$name = uniqid();
			file_put_contents("/var/www/medium/acc/".$_SESSION["account"]."/".$name, $file);
		}
?>

<p class="well">
welcome to the website of our new trendy startup idea, </pan style="color: red;">agrgtr</span>. agrgtr is a trendy name for a trendy concept: aggregating your favorite internet content in one place. someday we'll use the data we collect here to bring you good content automatically! but for now, please give type in a link to some funny pictures you find on the internet to keep them all in one accessible place: agrgtr!
<br/><br/>
delete your cookies to log out, it's the most secure way!
</p>

<form action="index.php" method="POST">
  URL to aggregate: <input type="text" name="url" size="50">
</form>

<h3>Aggregated user files:</h3>
<?php
		$files = scandir("/var/www/medium/acc/".$_SESSION["account"]);
		$files = array_slice($files, 2);
		foreach ($files as $file) {
			echo("<a href='/medium/acc/".$_SESSION["account"]."/$file'>$file</a><br/>");
		}
	} // end challenge block
?>

</div>
